//
//  BinaryFramework.h
//  BinaryFramework
//
//  Created by Aldo Junior Simoncini on 28/02/24.
//

#import <Foundation/Foundation.h>

//! Project version number for BinaryFramework.
FOUNDATION_EXPORT double BinaryFrameworkVersionNumber;

//! Project version string for BinaryFramework.
FOUNDATION_EXPORT const unsigned char BinaryFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BinaryFramework/PublicHeader.h>


